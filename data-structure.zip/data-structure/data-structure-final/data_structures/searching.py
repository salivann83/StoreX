class SearchingAlgorithms:
    @staticmethod
    def linear_search(arr, key_func, target):
        results = []
        for item in arr:
            if target.lower() in str(key_func(item)).lower():
                results.append(item)
        return results

    @staticmethod
    def binary_search(arr, key_func, target):
        """
        NOTE:
        - This implementation assumes `arr` is already sorted by `key_func`.
        - No built-in sorting is performed here (manual sorting should be done outside).
        """
        results = []
        low, high = 0, len(arr) - 1
        target_l = target.lower()

        while low <= high:
            mid = (low + high) // 2
            mid_value = str(key_func(arr[mid])).lower()

            if target_l in mid_value:
                results.append(arr[mid])

                left = mid - 1
                while left >= 0 and target_l in str(key_func(arr[left])).lower():
                    results.append(arr[left])
                    left -= 1

                right = mid + 1
                while right < len(arr) and target_l in str(key_func(arr[right])).lower():
                    results.append(arr[right])
                    right += 1

                return results

            elif mid_value < target_l:
                low = mid + 1
            else:
                high = mid - 1

        return results

    @staticmethod
    def jump_search(arr, key_func, target):
        """
        NOTE:
        - This implementation assumes `arr` is already sorted by `key_func`.
        - No built-in sorting is performed here (manual sorting should be done outside).
        """
        if not arr:
            return []

        n = len(arr)
        step = int(n**0.5)
        prev = 0
        target_l = target.lower()

        # Jump in blocks while last element of the block is still < target
        while (
            prev < n
            and str(key_func(arr[min(step, n) - 1])).lower() < target_l
        ):
            prev = step
            step += int(n**0.5)
            if prev >= n:
                return []

        results = []
        for i in range(prev, min(step, n)):
            if target_l in str(key_func(arr[i])).lower():
                results.append(arr[i])

                j = i - 1
                while j >= 0 and target_l in str(key_func(arr[j])).lower():
                    results.append(arr[j])
                    j -= 1

                j = i + 1
                while j < n and target_l in str(key_func(arr[j])).lower():
                    results.append(arr[j])
                    j += 1
                break

        return results
