from typing import Any, Optional

RED = True
BLACK = False


class RBNode:
    def __init__(self, key: Any, value: Any):
        self.key = key
        self.value = value
        self.color: bool = RED
        self.left: Optional["RBNode"] = None
        self.right: Optional["RBNode"] = None
        self.parent: Optional["RBNode"] = None

    def is_red(self) -> bool:
        return self.color == RED

    def is_black(self) -> bool:
        return self.color == BLACK

    def __repr__(self) -> str:
        color_str = "RED" if self.color else "BLACK"
        return f"RBNode(key={self.key}, value={self.value}, color={color_str})"


class RedBlackTree:
    def __init__(self):
        self.root: Optional[RBNode] = None

    def insert(self, key: Any, value: Any) -> None:
        """Insert a new node with the given key and value"""
        new_node = RBNode(key, value)

        if self.root is None:
            self.root = new_node
            self.root.color = BLACK
            return

        parent = None
        current = self.root

        while current is not None:
            parent = current
            if key < current.key:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent:
            if key < parent.key:
                parent.left = new_node
            else:
                parent.right = new_node

        self._fix_insert(new_node)

    def _fix_insert(self, node: RBNode) -> None:
        """Fix Red-Black tree properties after insertion"""
        while node != self.root and node.parent is not None and node.parent.is_red():
            parent = node.parent
            grandparent = parent.parent

            if grandparent is None:
                break

            if parent == grandparent.left:
                uncle = grandparent.right

                if uncle is not None and uncle.is_red():
                    parent.color = BLACK
                    uncle.color = BLACK
                    grandparent.color = RED
                    node = grandparent
                else:
                    if node == parent.right:
                        node = parent
                        self._left_rotate(node)
                        parent = node.parent
                        grandparent = parent.parent if parent else None

                    if parent:
                        parent.color = BLACK
                    if grandparent:
                        grandparent.color = RED
                        self._right_rotate(grandparent)
            else:
                uncle = grandparent.left

                if uncle is not None and uncle.is_red():
                    parent.color = BLACK
                    uncle.color = BLACK
                    grandparent.color = RED
                    node = grandparent
                else:
                    if node == parent.left:
                        node = parent
                        self._right_rotate(node)
                        parent = node.parent
                        grandparent = parent.parent if parent else None

                    if parent:
                        parent.color = BLACK
                    if grandparent:
                        grandparent.color = RED
                        self._left_rotate(grandparent)

        if self.root:
            self.root.color = BLACK

    def _left_rotate(self, x: RBNode) -> None:
        """Perform left rotation at node x"""
        y = x.right
        if y is None:
            return

        x.right = y.left
        if y.left is not None:
            y.left.parent = x

        y.parent = x.parent

        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def _right_rotate(self, y: RBNode) -> None:
        """Perform right rotation at node y"""
        x = y.left
        if x is None:
            return

        y.left = x.right
        if x.right is not None:
            x.right.parent = y

        x.parent = y.parent

        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def search(self, key: Any) -> Optional[Any]:
        """Search for a node with the given key"""
        node = self._search_node(self.root, key)
        return node.value if node else None

    def _search_node(self, node: Optional[RBNode], key: Any) -> Optional[RBNode]:
        """Internal method to search for a node"""
        if node is None or node.key == key:
            return node

        if key < node.key:
            return self._search_node(node.left, key)
        return self._search_node(node.right, key)

    def inorder_traversal(self) -> list:
        """Return all values in inorder traversal"""
        result: list = []
        self._inorder_traversal(self.root, result)
        return result

    def _inorder_traversal(self, node: Optional[RBNode], result: list) -> None:
        """Internal method for inorder traversal"""
        if node is not None:
            self._inorder_traversal(node.left, result)
            result.append(node.value)
            self._inorder_traversal(node.right, result)
