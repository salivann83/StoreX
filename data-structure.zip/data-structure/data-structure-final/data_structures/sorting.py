class SortingAlgorithms:
    @staticmethod
    def bubble_sort(arr, key_func):
        n = len(arr)
        for i in range(n - 1):
            for j in range(0, n - i - 1):
                if key_func(arr[j]) > key_func(arr[j + 1]):
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
        return arr

    @staticmethod
    def merge_sort(arr, key_func):
        if len(arr) <= 1:
            return arr

        mid = len(arr) // 2
        left = SortingAlgorithms.merge_sort(arr[:mid], key_func)
        right = SortingAlgorithms.merge_sort(arr[mid:], key_func)

        return SortingAlgorithms._merge(left, right, key_func)

    @staticmethod
    def _merge(left, right, key_func):
        result = []
        i = j = 0

        while i < len(left) and j < len(right):
            if key_func(left[i]) <= key_func(right[j]):
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1

        result.extend(left[i:])
        result.extend(right[j:])
        return result

    @staticmethod
    def quick_sort(arr, key_func):
        if len(arr) <= 1:
            return arr

        pivot = arr[len(arr) // 2]
        pivot_key = key_func(pivot)

        left = [x for x in arr if key_func(x) < pivot_key]
        middle = [x for x in arr if key_func(x) == pivot_key]
        right = [x for x in arr if key_func(x) > pivot_key]

        return (
            SortingAlgorithms.quick_sort(left, key_func)
            + middle
            + SortingAlgorithms.quick_sort(right, key_func)
        )
