class Product:
    id: int
    title: str
    category_id: int
    price: float
    score: int
    sell_count: int

    def __init__(self, id, title, category_id, price, score, sell_count):
        self.id = id
        self.title = title
        self.price = price
        self.category_id = category_id
        self.score = score
        self.sell_count = sell_count

    def __repr__(self):
        return f"Product(id={self.id}, title={self.title}, price={self.price}, category_id={self.category_id}, score={self.score}, sell_count={self.sell_count})"
