class Category:
    id: int
    title: str
    product_count: int

    def __init__(self, id, title, product_count=0):
        self.id = id
        self.title = title
        self.product_count = product_count

    def __repr__(self):
        return f"Category(id={self.id}, title={self.title}, product_count={self.product_count})"
