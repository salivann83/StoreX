from datetime import datetime


class CartItem:
    def __init__(self, product_id, product_title, price, quantity=1):
        self.product_id = product_id
        self.product_title = product_title
        self.price = price
        self.quantity = quantity

    @property
    def total_price(self):
        return self.price * self.quantity

    def __repr__(self):
        return f"CartItem(product_id={self.product_id}, title={self.product_title}, quantity={self.quantity}, total=${self.total_price:.2f})"


class Cart:
    def __init__(self, user_id):
        self.user_id = user_id
        self.items = []  # List of CartItem objects
        self.created_at = datetime.now()

    def add_item(self, product_id, product_title, price, quantity=1):
        for item in self.items:
            if item.product_id == product_id:
                item.quantity += quantity
                return item

        new_item = CartItem(product_id, product_title, price, quantity)
        self.items.append(new_item)
        return new_item

    def remove_item(self, product_id):
        self.items = [item for item in self.items if item.product_id != product_id]

    def update_quantity(self, product_id, quantity):
        for item in self.items:
            if item.product_id == product_id:
                if quantity <= 0:
                    self.remove_item(product_id)
                else:
                    item.quantity = quantity
                return True
        return False

    def clear(self):
        self.items.clear()

    @property
    def total_items(self):
        return sum(item.quantity for item in self.items)

    @property
    def total_price(self):
        return sum(item.total_price for item in self.items)

    def __repr__(self):
        return f"Cart(user_id={self.user_id}, items={len(self.items)}, total=${self.total_price:.2f})"
