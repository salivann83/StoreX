import csv

from data_structures.avl_tree import AVLTree
from data_structures.binary_search_tree import BinarySearchTree
from data_structures.searching import SearchingAlgorithms
from data_structures.sorting import SortingAlgorithms
from helpers.validator import validate_model
from models.category import Category
from views.category import (
    create_page_form,
    delete_page_form,
    list_page_form,
    list_page_view,
    search_form,
    search_view,
    update_page_form,
)

CATEGORY_DB_PATH = "database/category.csv"
PRODUCT_DB_PATH = "database/product.csv"


class CategoryController:
    def __init__(self, logger):
        self.logger = logger
        self.id_tree = BinarySearchTree()
        self.title_tree = AVLTree()
        self.load_data()
        self.update_product_counts()

    def load_data(self):
        with open(CATEGORY_DB_PATH, "r", newline="") as f:
            reader = csv.reader(f)
            next(reader, None)  # ✅ skip header
            for row in reader:
                if row and len(row) >= 2:
                    category = Category(
                        id=int(row[0]),
                        title=row[1],
                        product_count=int(row[2]) if len(row) > 2 else 0,
                    )
                    self.id_tree.insert(category.id, category)
                    self.title_tree.insert(category.title.lower(), category)

    def update_product_counts(self):
        categories = self.fetch_list()
        for category in categories:
            category.product_count = 0

        try:
            with open(PRODUCT_DB_PATH, "r", newline="") as f:
                reader = csv.reader(f)
                next(reader, None)  # ✅ skip header
                for row in reader:
                    if row and len(row) >= 3:
                        category_id = int(row[2])
                        category = self.get_by_id(category_id)
                        if category:
                            category.product_count += 1
        except FileNotFoundError:
            pass

        self._save_all_to_csv()

    def list_page(self, user_id=1):
        sortBy = list_page_form()
        categories = self.fetch_list()

        if sortBy == 1 or sortBy == 2:
            categories = SortingAlgorithms.bubble_sort(categories, lambda x: x.id)
        elif sortBy == 3 or sortBy == 4:
            categories = SortingAlgorithms.merge_sort(
                categories, lambda x: x.title.lower()
            )
        elif sortBy == 5 or sortBy == 6:
            categories = SortingAlgorithms.quick_sort(
                categories, lambda x: x.product_count
            )

        if sortBy in [2, 4, 6]:
            categories = list(reversed(categories))

        self.logger.log_action(user_id, "LIST_CATEGORIES", f"Sorted by: {sortBy}")
        return list_page_view(categories)

    def create_page(self, user_id=1):
        data = create_page_form()
        if not validate_model(Category, data):
            print("Invalid Category Data!")
            return

        self.create(data, user_id)

    def create(self, data: dict, user_id=1):
        categories = self.fetch_list()
        next_id = max([c.id for c in categories], default=0) + 1

        new_category = Category(id=next_id, title=data.get("title"), product_count=0)

        self.id_tree.insert(new_category.id, new_category)
        self.title_tree.insert(new_category.title.lower(), new_category)

        with open(CATEGORY_DB_PATH, "a", newline="") as f:
            csv.writer(f).writerow(
                [new_category.id, new_category.title, new_category.product_count]
            )

        self.logger.log_action(
            user_id,
            "CREATE_CATEGORY",
            f"ID: {new_category.id}, Title: {new_category.title}",
        )
        print(
            f"\nCategory '{new_category.title}' created successfully with ID: {new_category.id}"
        )

    def update_page(self, user_id=1):
        result = update_page_form()
        if not result:
            return

        category_id, data = result
        category = self.get_by_id(category_id)

        if not category:
            print(f"Category with ID {category_id} not found!")
            return

        old_title = category.title.lower()

        if "title" in data and data["title"]:
            category.title = data["title"]

            self._save_all_to_csv()
            self.id_tree = BinarySearchTree()
            self.title_tree = AVLTree()
            self.load_data()

        self.logger.log_action(user_id, "UPDATE_CATEGORY", f"ID: {category_id}")
        print(f"Category ID {category_id} updated successfully!")

    def delete_page(self, user_id=1):
        category_id = delete_page_form()

        if category_id is None:
            return

        category = self.get_by_id(category_id)

        if not category:
            print(f"Category with ID {category_id} not found!")
            return

        if category.product_count > 0:
            print(f"\n⚠️  WARNING: This category has {category.product_count} products!")
            print("Deleting it will orphan these products.")
            confirm = input("Do you still want to delete? (y/n): ").lower()
            if confirm != "y":
                print("Deletion cancelled.")
                return

        categories = self.fetch_list()
        categories = [c for c in categories if c.id != category_id]

        self._save_categories_to_csv(categories)

        self.id_tree = BinarySearchTree()
        self.title_tree = AVLTree()
        self.load_data()

        self.logger.log_action(user_id, "DELETE_CATEGORY", f"ID: {category_id}")
        print(f"Category ID {category_id} deleted successfully!")

    def search(self, user_id=1):
        query = search_form()
        categories = self.fetch_list()

        if not query:
            print("Please enter a search query.")
            return

        print("\nChoose search algorithm:")
        print("1. Linear Search")
        print("2. Binary Search (requires sorted data)")
        print("3. Jump Search")

        try:
            choice = int(input("Enter choice (1-3): "))
        except ValueError:
            choice = 1

        if choice == 1:
            results = SearchingAlgorithms.linear_search(
                categories, lambda x: x.title, query
            )

        elif choice == 2:
            categories_by_title = SortingAlgorithms.merge_sort(
                categories, lambda x: x.title.lower()
            )
            results = SearchingAlgorithms.binary_search(
                categories_by_title, lambda x: x.title, query
            )

        elif choice == 3:
            categories_by_title = SortingAlgorithms.merge_sort(
                categories, lambda x: x.title.lower()
            )
            results = SearchingAlgorithms.jump_search(
                categories_by_title, lambda x: x.title, query
            )

        else:
            print("Invalid choice, using linear search")
            results = SearchingAlgorithms.linear_search(
                categories, lambda x: x.title, query
            )
            choice = 1

        self.logger.log_action(
            user_id,
            "SEARCH_CATEGORIES",
            f"Query: '{query}', Algorithm: {choice}, Results: {len(results)}",
        )
        return search_view(results)

    def fetch_list(self):
        return self.id_tree.inorder_traversal()

    def get_by_id(self, category_id):
        return self.id_tree.search(category_id)

    def get_by_title(self, title):
        return self.title_tree.search(title.lower())

    def _save_all_to_csv(self):
        categories = self.fetch_list()
        self._save_categories_to_csv(categories)

    def _save_categories_to_csv(self, categories):
        with open(CATEGORY_DB_PATH, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "title", "product_count"])  # ✅ add header
            for category in categories:
                writer.writerow([category.id, category.title, category.product_count])

    def increment_product_count(self, category_id):
        category = self.get_by_id(category_id)
        if category:
            category.product_count += 1
            self._update_category_in_csv(category)

    def decrement_product_count(self, category_id):
        category = self.get_by_id(category_id)
        if category and category.product_count > 0:
            category.product_count -= 1
            self._update_category_in_csv(category)

    def _update_category_in_csv(self, category):
        categories = self.fetch_list()
        with open(CATEGORY_DB_PATH, "w", newline="") as f:
             writer = csv.writer(f)
             writer.writerow(["id", "title", "product_count"])  # ✅ add header
             for cat in categories:
                 if cat.id == category.id:
                     writer.writerow([category.id, category.title, category.product_count])
                 else:
                     writer.writerow([cat.id, cat.title, cat.product_count])
 