from controllers.cart import CartController
from controllers.category import CategoryController
from controllers.product import ProductController
from helpers.input import input_handler
from views.cart import add_to_cart_form


class HomeController:
    def __init__(self, logger):
        self.logger = logger
        self.productController = ProductController(logger)
        self.categoryController = CategoryController(logger)
        self.cartController = CartController(logger, self.productController)

    def home_page(self, user_id=1):
        print("""
  Welcome to melz offline shop:

  PRODUCTS:
    1. List Products
    2. Create Product
    3. Search Products
    4. Search by Price Range
    5. Search by Category
    6. View Product Details
    7. Recently Viewed Products

  CATEGORIES:
    8. List Categories
    9. Create Category
    10. Search Categories
    11. Update Category
    12. Delete Category

  CART:
    13. View Cart
    14. Cart Menu

  SYSTEM:
    15. View Statistics
    0. Exit

  Enter your choice: """)

        command = input_handler(max_command=15)

        try:
            if command == 1:
                self.productController.list_page(user_id)
            elif command == 2:
                self.productController.create_page(user_id)
            elif command == 3:
                self.productController.search(user_id)
            elif command == 4:
                self.productController.search_by_price_range(user_id)
            elif command == 5:
                self.productController.search_by_category(
                    user_id, self.categoryController
                )
            elif command == 6:
                self._view_product_details(user_id)
            elif command == 7:
                self.productController.show_recently_viewed(user_id)
            elif command == 8:
                self.categoryController.list_page(user_id)
            elif command == 9:
                self.categoryController.create_page(user_id)
            elif command == 10:
                self.categoryController.search(user_id)
            elif command == 11:
                self.categoryController.update_page(user_id)
            elif command == 12:
                self.categoryController.delete_page(user_id)
            elif command == 13:
                self.cartController.view_cart(user_id)
            elif command == 14:
                self.cartController.cart_menu(user_id)
            elif command == 15:
                self.show_statistics(user_id)
            elif command == 0:
                 print("\n✅ Exit cancelled. You are back to the main menu.")
                 return


        except Exception as e:
            print(f"Error: {e}")
            self.logger.log_action(user_id, "ERROR", str(e))

    def _view_product_details(self, user_id):
        """Helper method to view product details"""
        try:
            product_id = int(input("Enter product ID to view details: "))
            result = self.productController.product_detail_page(user_id, product_id)

            if result and result[0] == "add_to_cart":
                _, product, quantity = result
                self.cartController.add_to_cart(
                    user_id, product.id, product.title, product.price, quantity
                )
                print(f"✅ Added {quantity} x {product.title} to cart!")
        except ValueError:
            print("❌ Invalid product ID!")

    def show_statistics(self, user_id=1):
        """Show comprehensive system statistics"""
        products = self.productController.fetch_list()
        categories = self.categoryController.fetch_list()

        print("\n" + "=" * 70)
        print("📊 SYSTEM STATISTICS")
        print("=" * 70)

        # Basic counts
        print(f"\n📦 PRODUCTS:")
        print(f"  • Total Products: {len(products)}")
        if products:
            prices = [p.price for p in products]
            print(f"  • Average Price: ${sum(prices) / len(prices):.2f}")
            print(f"  • Highest Price: ${max(prices):.2f}")
            print(f"  • Lowest Price: ${min(prices):.2f}")
            print(f"  • Total Units Sold: {sum(p.sell_count for p in products)}")

        print(f"\n🏷️ CATEGORIES:")
        print(f"  • Total Categories: {len(categories)}")
        if categories:
            print(
                f"  • Average Products per Category: {sum(c.product_count for c in categories) / len(categories):.2f}"
            )
            print(
                f"  • Most Products in Category: {max(c.product_count for c in categories)}"
            )
            print(
                f"  • Least Products in Category: {min(c.product_count for c in categories)}"
            )

        # Categories by product count
        if categories:
            print(f"\n🏆 TOP CATEGORIES BY PRODUCT COUNT:")
            print("-" * 70)
            print(f"{'Rank':<6} {'Category':<25} {'Products':<10} {'% of Total':<10}")
            print("-" * 70)

            sorted_cats = sorted(
                categories, key=lambda x: x.product_count, reverse=True
            )
            total_products = sum(c.product_count for c in categories)

            for i, cat in enumerate(sorted_cats[:10], 1):  # Show top 10
                percentage = (
                    (cat.product_count / total_products * 100)
                    if total_products > 0
                    else 0
                )
                print(
                    f"{i:<6} {cat.title[:24]:<25} {cat.product_count:<10} {percentage:.1f}%"
                )

            print("-" * 70)

        # Product price distribution
        if products:
            print(f"\n💰 PRICE DISTRIBUTION:")
            print("-" * 70)

            # Define price ranges
            price_ranges = [
                (0, 10, "Under $10"),
                (10, 25, "$10 - $25"),
                (25, 50, "$25 - $50"),
                (50, 100, "$50 - $100"),
                (100, 250, "$100 - $250"),
                (250, float("inf"), "Over $250"),
            ]

            total_products = len(products)

            for min_price, max_price, label in price_ranges:
                count = len([p for p in products if min_price <= p.price < max_price])
                if count > 0:
                    percentage = count / total_products * 100
                    bar_length = int(percentage / 5)  # Scale to max 20 chars
                    bar = "█" * bar_length
                    print(
                        f"{label:<15} {count:<4} products {percentage:>5.1f}% [{bar:<20}]"
                    )

            print("-" * 70)

        # Best selling products
        if products:
            print(f"\n🔥 BEST SELLING PRODUCTS:")
            print("-" * 70)
            print(
                f"{'ID':<6} {'Product':<25} {'Sold':<8} {'Price':<10} {'Revenue':<12}"
            )
            print("-" * 70)

            sorted_products = sorted(products, key=lambda x: x.sell_count, reverse=True)
            for product in sorted_products[:5]:  # Top 5
                revenue = product.price * product.sell_count
                print(
                    f"{product.id:<6} {product.title[:24]:<25} "
                    f"{product.sell_count:<8} ${product.price:<9.2f} ${revenue:<11.2f}"
                )

            print("-" * 70)
            total_revenue = sum(p.price * p.sell_count for p in products)
            print(f"Total Revenue Generated: ${total_revenue:.2f}")

        # Cart statistics
        cart = self.cartController.get_user_cart(user_id)
        if cart.items:
            print(f"\n🛒 YOUR CART STATISTICS:")
            print("-" * 70)
            print(f"  • Items in Cart: {cart.total_items}")
            print(f"  • Unique Products: {len(cart.items)}")
            print(f"  • Cart Value: ${cart.total_price:.2f}")
            print(
                f"  • Average Price per Item: ${cart.total_price / cart.total_items:.2f}"
            )
            print("-" * 70)

        # Recently viewed
        recent_products = self.productController.recently_viewed.get(user_id, [])
        if recent_products:
            print(f"\n👀 YOUR RECENT ACTIVITY:")
            print("-" * 70)
            print(f"  • Recently Viewed Products: {len(recent_products)}")
            print(
                f"  • Last Viewed: {recent_products[0].title if recent_products else 'None'}"
            )
            print("-" * 70)

        # System information
        print(f"\n⚙️ SYSTEM INFORMATION:")
        print("-" * 70)
        import datetime

        now = datetime.datetime.now()
        print(f"  • Current Date: {now.strftime('%Y-%m-%d')}")
        print(f"  • Current Time: {now.strftime('%H:%M:%S')}")
        print(f"  • Total Users: 1 (Demo Mode)")
        print(f"  • Database Files: 3 (products, categories, carts)")

        # Performance metrics
        print(f"\n📈 PERFORMANCE METRICS:")
        print("-" * 70)
        print(f"  • Data Structures:")
        print(
            f"    - Binary Search Tree: {len(self.productController.id_tree.inorder_traversal())} products"
        )
        print(
            f"    - Red-Black Tree: {len(self.productController.price_tree.inorder_traversal())} products"
        )
        print(
            f"    - AVL Tree: {len(self.categoryController.title_tree.inorder_traversal())} categories"
        )
        print(f"  • Search Algorithms Available:")
        print(f"    - Linear Search")
        print(f"    - Binary Search")
        print(f"    - Jump Search")
        print(f"  • Sort Algorithms Available:")
        print(f"    - Bubble Sort")
        print(f"    - Merge Sort")
        print(f"    - Quick Sort")

        print("=" * 70)

        # Save to log
        self.logger.log_action(
            user_id,
            "VIEW_STATISTICS",
            f"Products: {len(products)}, Categories: {len(categories)}",
        )
