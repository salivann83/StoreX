import csv

from data_structures.binary_search_tree import BinarySearchTree
from data_structures.red_black_tree import RedBlackTree
from data_structures.searching import SearchingAlgorithms
from data_structures.sorting import SortingAlgorithms
from helpers.validator import validate_model
from models.product import Product
from views.product import (
    add_to_cart_form,
    clear_recent_history_confirmation,
    create_page_form,
    delete_page_form,
    list_page_form,
    list_page_view,
    product_detail_full_view,
    recently_watched_view,
    search_form,
    search_view,
    set_recent_limit_form,
    similar_products_form,
    update_page_form,
)

PRODUCT_DB_PATH = "database/product.csv"


class ProductController:
    def __init__(self, logger):
        self.logger = logger
        self.id_tree = BinarySearchTree()
        self.price_tree = RedBlackTree()
        self.recently_viewed = {}  # user_id -> list of recently viewed products
        self.recent_limit = 5  # Default limit for recently viewed
        self.load_data()

    def load_data(self):
        """Load products from CSV into data structures"""
        try:
            with open(PRODUCT_DB_PATH, "r", newline="") as f:
                reader = csv.reader(f)
                next(reader, None)  # Skip header if exists
                for row in reader:
                    if row and len(row) >= 6:
                        product = Product(
                            id=int(row[0]),
                            title=row[1],
                            category_id=int(row[2]),
                            price=float(row[3]),
                            score=int(row[4]),
                            sell_count=int(row[5]),
                        )
                        self.id_tree.insert(product.id, product)

                        # ✅ unique key to avoid collisions when prices repeat
                        self.price_tree.insert((product.price, product.id), product)

        except FileNotFoundError:
            print("Product database not found. Starting with empty database.")
        except StopIteration:
            print("Product database is empty.")

    def list_page(self, user_id=1):
        sortBy, category_id = list_page_form()
        products = self.fetch_list()

        if category_id > 0:
            products = [p for p in products if p.category_id == category_id]

        if sortBy == 1 or sortBy == 2:
            products = SortingAlgorithms.bubble_sort(products, lambda x: x.id)
        elif sortBy == 3 or sortBy == 4:
            products = SortingAlgorithms.merge_sort(products, lambda x: x.title.lower())
        elif sortBy == 5 or sortBy == 6:
            products = SortingAlgorithms.quick_sort(products, lambda x: x.price)

        if sortBy in [2, 4, 6]:
            products = list(reversed(products))

        self.logger.log_action(user_id, "LIST_PRODUCTS", f"Sorted by: {sortBy}")
        return list_page_view(products)

    def create_page(self, user_id=1):
        data = create_page_form()
        if not validate_model(Product, data):
            print("Invalid Product Data!")
            return

        self.create(data, user_id)

    def create(self, data: dict, user_id=1):
        products = self.fetch_list()
        next_id = max([p.id for p in products], default=0) + 1

        new_product = Product(
            id=next_id,
            title=data.get("title"),
            category_id=int(data.get("category_id", 1)),
            price=float(data.get("price", 0)),
            score=0,
            sell_count=0,
        )

        self.id_tree.insert(new_product.id, new_product)
        self.price_tree.insert((new_product.price, new_product.id), new_product)

        with open(PRODUCT_DB_PATH, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    new_product.id,
                    new_product.title,
                    new_product.category_id,
                    new_product.price,
                    new_product.score,
                    new_product.sell_count,
                ]
            )

        self.logger.log_action(
            user_id,
            "CREATE_PRODUCT",
            f"ID: {new_product.id}, Title: {new_product.title}",
        )
        print(f"Product '{new_product.title}' created successfully!")

    def update_page(self, user_id=1):
        product_id, data = update_page_form()
        product = self.get_by_id(product_id)

        if not product:
            print(f"Product with ID {product_id} not found!")
            return

        # ✅ Safe updates with type casting
        if "title" in data and data["title"] is not None:
            product.title = str(data["title"])

        if "price" in data and data["price"] is not None:
            try:
                product.price = float(data["price"])
            except ValueError:
                print("❌ Invalid price!")
                return

        if "category_id" in data and data["category_id"] is not None:
            try:
                product.category_id = int(data["category_id"])
            except ValueError:
                print("❌ Invalid category ID!")
                return

        # Save all to CSV
        self._save_all_to_csv()

        # ✅ Rebuild trees to keep them consistent (especially price_tree key)
        self.id_tree = BinarySearchTree()
        self.price_tree = RedBlackTree()
        self.load_data()

        self.logger.log_action(user_id, "UPDATE_PRODUCT", f"ID: {product_id}")
        print(f"Product ID {product_id} updated successfully!")

    def delete_page(self, user_id=1):
        product_id = delete_page_form()
        product = self.get_by_id(product_id)

        if not product:
            print(f"Product with ID {product_id} not found!")
            return

        products = self.fetch_list()
        products = [p for p in products if p.id != product_id]

        self._save_products_to_csv(products)

        self.id_tree = BinarySearchTree()
        self.price_tree = RedBlackTree()
        self.load_data()

        self.logger.log_action(user_id, "DELETE_PRODUCT", f"ID: {product_id}")
        print(f"Product ID {product_id} deleted successfully!")

    def search(self, user_id=1):
        query = search_form()
        products = self.fetch_list()

        print("\nChoose search algorithm:")
        print("1. Linear Search")
        print("2. Binary Search (requires sorted data)")
        print("3. Jump Search")

        try:
            choice = int(input("Enter choice (1-3): "))
        except ValueError:
            choice = 1

        query_norm = str(query).strip().lower()

        if choice == 1:
            results = SearchingAlgorithms.linear_search(
                products, lambda x: x.title.lower(), query_norm
            )

        elif choice in (2, 3):
            # ✅ IMPORTANT: binary/jump search needs data sorted by the SAME key (title)
            products_by_title = SortingAlgorithms.merge_sort(
                products, lambda x: x.title.lower()
            )

            if choice == 2:
                results = SearchingAlgorithms.binary_search(
                    products_by_title, lambda x: x.title.lower(), query_norm
                )
            else:
                results = SearchingAlgorithms.jump_search(
                    products_by_title, lambda x: x.title.lower(), query_norm
                )

        else:
            print("Invalid choice, using linear search")
            results = SearchingAlgorithms.linear_search(
                products, lambda x: x.title.lower(), query_norm
            )
            choice = 1

        self.logger.log_action(
            user_id, "SEARCH_PRODUCTS", f"Query: {query}, Algorithm: {choice}"
        )
        return search_view(results)

    def get_similar_products(self, user_id=1):
        product_id, criteria, limit = similar_products_form()
        product = self.get_by_id(product_id)

        if not product:
            print(f"Product with ID {product_id} not found!")
            return

        similar_products = self._get_similar_products(product, criteria, limit)
        self._display_similar_products(product, similar_products, criteria)

        self.logger.log_action(
            user_id, "SIMILAR_PRODUCTS", f"For ID: {product_id}, Criteria: {criteria}"
        )

    def _get_similar_products(self, product, criteria, limit=5):
        """Find similar products based on criteria"""
        all_products = self.fetch_list()
        similar_products = []

        if criteria == 1:
            similar_products = [
                p
                for p in all_products
                if p.category_id == product.category_id and p.id != product.id
            ]
            similar_products.sort(key=lambda x: abs(x.price - product.price))

        elif criteria == 2:
            price_range = product.price * 0.2
            similar_products = [
                p
                for p in all_products
                if abs(p.price - product.price) <= price_range and p.id != product.id
            ]
            similar_products.sort(
                key=lambda x: (
                    x.category_id != product.category_id,
                    abs(x.price - product.price),
                )
            )

        elif criteria == 3:
            similar_products = [
                p
                for p in all_products
                if p.category_id == product.category_id and p.id != product.id
            ]
            similar_products.sort(key=lambda x: x.sell_count, reverse=True)

        return similar_products[:limit]

    def _display_similar_products(self, main_product, similar_products, criteria):
        """Display similar products"""
        criteria_names = {
            1: "Same Category",
            2: "Similar Price (±20%)",
            3: "Most Bought in Same Category",
        }

        print("\n" + "=" * 70)
        print(f"SIMILAR PRODUCTS - {criteria_names.get(criteria, 'Unknown Criteria')}")
        print("=" * 70)

        print(f"\n📋 Main Product:")
        print(f"   ID: {main_product.id}")
        print(f"   Title: {main_product.title}")
        print(f"   Category: {main_product.category_id}")
        print(f"   Price: ${main_product.price:.2f}")
        print(f"   Sold: {main_product.sell_count} times")

        print("\n" + "-" * 70)

        if similar_products:
            print(f"\n🔍 Found {len(similar_products)} similar products:")
            print("-" * 70)
            print(
                f"{'ID':<6} {'Title':<30} {'Price':<12} {'Sold':<10} {'Category':<10}"
            )
            print("-" * 70)

            for product in similar_products:
                print(
                    f"{product.id:<6} "
                    f"{product.title[:29]:<30} "
                    f"${product.price:<11.2f} "
                    f"{product.sell_count:<10} "
                    f"{product.category_id:<10}"
                )

            print("-" * 70)

            avg_price = sum(p.price for p in similar_products) / len(similar_products)
            total_sold = sum(p.sell_count for p in similar_products)
            print(f"\n📊 Similar Products Statistics:")
            print(f"   • Average Price: ${avg_price:.2f}")
            print(f"   • Total Sold: {total_sold} units")
            print(
                f"   • Price Range: ${min(p.price for p in similar_products):.2f} - ${max(p.price for p in similar_products):.2f}"
            )
        else:
            print("\n❌ No similar products found.")

        print("=" * 70)

    def product_detail_page(self, user_id, product_id):
        """Display product details and handle actions"""
        product = self.get_by_id(product_id)
        if not product:
            print(f"Product with ID {product_id} not found!")
            return None

        self._add_to_recently_viewed(user_id, product)

        category_title = f"Category {product.category_id}"
        similar_products = self._get_similar_products(product, criteria=1, limit=3)
        product_info = product_detail_full_view(product, category_title)

        print("\n" + "=" * 70)
        print("🛍️  SHOPPING OPTIONS")
        print("=" * 70)
        print("1. Add to Cart")
        print("2. View Similar Products")
        print("3. Compare with Similar Products")
        print("4. Back to Product List")
        print("=" * 70)

        try:
            choice = int(input("\nSelect option (1-4): "))

            if choice == 1:
                quantity = add_to_cart_form(
                    product.title, product.price, product_info.get("stock_count", 100)
                )
                if quantity:
                    return "add_to_cart", product, quantity

            elif choice == 2:
                self._display_similar_products(product, similar_products, 1)
                input("\nPress Enter to continue...")

            elif choice == 3:
                if similar_products:
                    from views.product import product_comparison_view

                    comparison_products = [product] + similar_products[:2]
                    result = product_comparison_view(comparison_products)
                    if result and result <= len(comparison_products):
                        selected_product = comparison_products[result - 1]
                        quantity = add_to_cart_form(
                            selected_product.title,
                            selected_product.price,
                            product_info.get("stock_count", 100),
                        )
                        if quantity:
                            return "add_to_cart", selected_product, quantity
                else:
                    print("No similar products to compare with.")

            elif choice == 4:
                return "back"

        except ValueError:
            print("Invalid input!")

        return None

    def _add_to_recently_viewed(self, user_id, product):
        """Add product to user's recently viewed list"""
        if user_id not in self.recently_viewed:
            self.recently_viewed[user_id] = []

        self.recently_viewed[user_id] = [
            p for p in self.recently_viewed[user_id] if p.id != product.id
        ]

        self.recently_viewed[user_id].insert(0, product)

        if len(self.recently_viewed[user_id]) > 50:
            self.recently_viewed[user_id] = self.recently_viewed[user_id][:50]

    def show_recently_viewed(self, user_id):
        """Show recently viewed products menu"""
        while True:
            recent_products = self.recently_viewed.get(user_id, [])
            choice = recently_watched_view(recent_products, self.recent_limit)

            if choice == 1:
                if recent_products:
                    try:
                        product_num = int(
                            input(
                                f"Enter product number (1-{min(self.recent_limit, len(recent_products))}): "
                            )
                        )
                        if 1 <= product_num <= len(recent_products):
                            product = recent_products[product_num - 1]
                            result = self.product_detail_page(user_id, product.id)
                            if result and result[0] == "add_to_cart":
                                return result
                        else:
                            print("Invalid product number!")
                    except ValueError:
                        print("Invalid input!")
                else:
                    print("No recently viewed products!")

            elif choice == 2:
                if recent_products:
                    try:
                        product_num = int(
                            input(
                                f"Enter product number to add to cart (1-{min(self.recent_limit, len(recent_products))}): "
                            )
                        )
                        if 1 <= product_num <= len(recent_products):
                            product = recent_products[product_num - 1]
                            quantity = add_to_cart_form(product.title, product.price)
                            if quantity:
                                return "add_to_cart", product, quantity
                        else:
                            print("Invalid product number!")
                    except ValueError:
                        print("Invalid input!")

            elif choice == 3:
                if len(recent_products) >= 2:
                    from views.product import product_comparison_view

                    comparison_products = recent_products[: min(4, len(recent_products))]
                    result = product_comparison_view(comparison_products)
                    if result and result <= len(comparison_products):
                        selected_product = comparison_products[result - 1]
                        quantity = add_to_cart_form(
                            selected_product.title, selected_product.price
                        )
                        if quantity:
                            return "add_to_cart", selected_product, quantity
                else:
                    print("Need at least 2 products to compare!")

            elif choice == 4:
                new_limit = set_recent_limit_form(self.recent_limit)
                if new_limit != self.recent_limit:
                    self.recent_limit = new_limit
                    print(f"✅ Display limit changed to {new_limit} products")

            elif choice == 5:
                if clear_recent_history_confirmation(len(recent_products)):
                    self.recently_viewed[user_id] = []
                    print("✅ Watch history cleared!")

            elif choice == 6:
                break

            else:
                print("Invalid choice!")

    def search_by_price_range(self, user_id):
        """Search products by price range"""
        print("\n" + "=" * 60)
        print("💰 SEARCH BY PRICE RANGE")
        print("=" * 60)

        try:
            min_price = float(input("Enter minimum price: $"))
            max_price = float(input("Enter maximum price: $"))

            if min_price < 0 or max_price < 0:
                print("❌ Price cannot be negative!")
                return

            if min_price > max_price:
                print("❌ Minimum price cannot be greater than maximum price!")
                return

            all_products = self.price_tree.inorder_traversal()
            results = [p for p in all_products if min_price <= p.price <= max_price]

            if results:
                print(
                    f"\n✅ Found {len(results)} products in price range ${min_price:.2f} - ${max_price:.2f}:"
                )
                print("-" * 60)
                for product in results[:20]:
                    print(
                        f"ID: {product.id}, {product.title}, Price: ${product.price:.2f}, Category: {product.category_id}"
                    )

                if len(results) > 20:
                    print(f"... and {len(results) - 20} more products")

                print("-" * 60)

                view_detail = input("\nView product details? (y/n): ").lower()
                if view_detail == "y":
                    try:
                        product_id = int(input("Enter product ID to view details: "))
                        self.product_detail_page(user_id, product_id)
                    except ValueError:
                        print("❌ Invalid product ID!")
            else:
                print(
                    f"\n❌ No products found in price range ${min_price:.2f} - ${max_price:.2f}"
                )

            self.logger.log_action(
                user_id,
                "SEARCH_BY_PRICE_RANGE",
                f"Range: ${min_price:.2f}-${max_price:.2f}, Results: {len(results)}",
            )

        except ValueError:
            print("❌ Invalid price input!")

    def search_by_category(self, user_id, category_controller):
        """Search products by category"""
        print("\n" + "=" * 60)
        print("🏷️  SEARCH BY CATEGORY")
        print("=" * 60)

        categories = category_controller.fetch_list()
        if not categories:
            print("❌ No categories available!")
            return

        print("Available Categories:")
        print("-" * 60)
        for category in categories:
            print(
                f"ID: {category.id}, Title: {category.title}, Products: {category.product_count}"
            )
        print("-" * 60)

        try:
            category_id = int(input("Enter category ID: "))
            category = category_controller.get_by_id(category_id)

            if not category:
                print(f"❌ Category with ID {category_id} not found!")
                return

            all_products = self.fetch_list()
            results = [p for p in all_products if p.category_id == category_id]

            if results:
                print(
                    f"\n✅ Found {len(results)} products in category '{category.title}':"
                )
                print("-" * 60)
                for product in results[:20]:
                    print(
                        f"ID: {product.id}, {product.title}, Price: ${product.price:.2f}"
                    )

                if len(results) > 20:
                    print(f"... and {len(results) - 20} more products")

                print("-" * 60)

                view_detail = input("\nView product details? (y/n): ").lower()
                if view_detail == "y":
                    try:
                        product_id = int(input("Enter product ID to view details: "))
                        self.product_detail_page(user_id, product_id)
                    except ValueError:
                        print("❌ Invalid product ID!")
            else:
                print(f"\n❌ No products found in category '{category.title}'")

            self.logger.log_action(
                user_id,
                "SEARCH_BY_CATEGORY",
                f"Category: {category.title}, Results: {len(results)}",
            )

        except ValueError:
            print("❌ Invalid category ID!")

    def fetch_list(self):
        """Fetch all products"""
        return self.id_tree.inorder_traversal()

    def get_by_id(self, product_id):
        """Get product by ID"""
        return self.id_tree.search(product_id)

    def get_by_price_range(self, min_price, max_price):
        """Get products within price range using Red-Black tree"""
        all_products = self.price_tree.inorder_traversal()
        return [p for p in all_products if min_price <= p.price <= max_price]

    def _save_all_to_csv(self):
        """Save all products to CSV"""
        products = self.fetch_list()
        self._save_products_to_csv(products)

    def _save_products_to_csv(self, products):
        """Save products list to CSV file"""
        try:
            with open(PRODUCT_DB_PATH, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(
                    ["id", "title", "category_id", "price", "score", "sell_count"]
                )
                for product in products:
                    writer.writerow(
                        [
                            product.id,
                            product.title,
                            product.category_id,
                            product.price,
                            product.score,
                            product.sell_count,
                        ]
                    )
        except Exception as e:
            print(f"Error saving products to CSV: {e}")
