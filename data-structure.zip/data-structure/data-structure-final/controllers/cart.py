import csv
import os
from datetime import datetime

from models.cart import Cart
from views.cart import cart_menu_view, cart_view

CART_DB_PATH = "database/carts.csv"


class CartController:
    def __init__(self, logger, product_controller):
        self.logger = logger
        self.product_controller = product_controller
        self.user_carts = {}  # user_id -> Cart
        self.load_carts()

    def load_carts(self):
        """Load carts from CSV (skips header safely)"""
        if not os.path.exists(CART_DB_PATH):
            return

        with open(CART_DB_PATH, "r", newline="") as f:
            reader = csv.reader(f)

            # skip header
            next(reader, None)

            for row in reader:
                if not row or len(row) < 5:
                    continue
                if row[0] == "user_id":
                    continue

                try:
                    user_id = int(row[0])
                    product_id = int(row[1])
                    quantity = int(row[4])
                except ValueError:
                    continue

                product = self.product_controller.get_by_id(product_id)
                if product:
                    self.add_to_cart(
                        user_id,
                        product_id,
                        product.title,
                        product.price,
                        quantity,
                        save_to_csv=False,
                    )

    def save_cart_to_csv(self, user_id):
        """Save user's cart to CSV (keeps header)"""
        cart = self.get_user_cart(user_id)

        existing_items = []
        header = None

        if os.path.exists(CART_DB_PATH):
            with open(CART_DB_PATH, "r", newline="") as f:
                reader = csv.reader(f)
                header = next(reader, None)

                for row in reader:
                    if not row or len(row) < 1:
                        continue
                    if row[0] == "user_id":
                        continue

                    try:
                        row_user_id = int(row[0])
                    except ValueError:
                        continue

                    if row_user_id != user_id:
                        existing_items.append(row)

        if not header:
            header = ["user_id", "product_id", "product_title", "price", "quantity", "added_at"]

        with open(CART_DB_PATH, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(existing_items)

            for item in cart.items:
                writer.writerow(
                    [
                        user_id,
                        item.product_id,
                        item.product_title,
                        item.price,
                        item.quantity,
                        datetime.now().isoformat(),
                    ]
                )

    def get_user_cart(self, user_id):
        """Get or create cart for user"""
        if user_id not in self.user_carts:
            self.user_carts[user_id] = Cart(user_id)
        return self.user_carts[user_id]

    def add_to_cart(self, user_id, product_id, product_title, price, quantity=1, save_to_csv=True):
        """Add item to user's cart"""
        cart = self.get_user_cart(user_id)
        item = cart.add_item(product_id, product_title, price, quantity)

        if save_to_csv:
            self.save_cart_to_csv(user_id)
            self.logger.log_action(
                user_id,
                "ADD_TO_CART",
                f"Product ID: {product_id}, Quantity: {quantity}",
            )
        return item

    def remove_from_cart(self, user_id, product_id):
        """Remove item from user's cart"""
        cart = self.get_user_cart(user_id)
        cart.remove_item(product_id)
        self.save_cart_to_csv(user_id)
        self.logger.log_action(user_id, "REMOVE_FROM_CART", f"Product ID: {product_id}")

    def update_cart_item(self, user_id, product_id, quantity):
        """Update quantity of item in cart"""
        cart = self.get_user_cart(user_id)
        success = cart.update_quantity(product_id, quantity)

        if success:
            self.save_cart_to_csv(user_id)
            self.logger.log_action(
                user_id,
                "UPDATE_CART_ITEM",
                f"Product ID: {product_id}, New Quantity: {quantity}",
            )
        return success

    def clear_cart(self, user_id):
        """Clear user's cart"""
        cart = self.get_user_cart(user_id)
        cart.clear()
        self.save_cart_to_csv(user_id)
        self.logger.log_action(user_id, "CLEAR_CART", "")

    def view_cart(self, user_id):
        """Display user's cart"""
        cart = self.get_user_cart(user_id)
        cart_view(cart.items, cart.total_price, cart.total_items)
        self.logger.log_action(user_id, "VIEW_CART", f"Items: {cart.total_items}")

    def checkout(self, user_id):
        """Process checkout"""
        cart = self.get_user_cart(user_id)

        if not cart.items:
            print("Your cart is empty!")
            return

        print("\n" + "=" * 60)
        print("CHECKOUT SUMMARY")
        print("=" * 60)
        cart_view(cart.items, cart.total_price, cart.total_items)
        print("\n" + "=" * 60)

        confirm = input("Confirm purchase? (y/n): ").lower()
        if confirm == "y":
            for item in cart.items:
                product = self.product_controller.get_by_id(item.product_id)
                if product:
                    product.sell_count += item.quantity
                    self.product_controller._save_all_to_csv()

            self.clear_cart(user_id)
            print("Purchase completed successfully! Thank you!")
            self.logger.log_action(
                user_id,
                "CHECKOUT",
                f"Total: ${cart.total_price:.2f}, Items: {cart.total_items}",
            )
        else:
            print("Checkout cancelled.")

    def cart_menu(self, user_id):
        """Display cart menu and handle actions"""
        while True:
            choice = cart_menu_view()

            if choice == "1":
                self.view_cart(user_id)
            elif choice == "2":
                self._update_item_quantity(user_id)
            elif choice == "3":
                self._remove_item(user_id)
            elif choice == "4":
                self.clear_cart(user_id)
                print("Cart cleared!")
            elif choice == "5":
                self.checkout(user_id)
                break
            elif choice == "6":
                break
            else:
                print("Invalid choice!")

    def _update_item_quantity(self, user_id):
        cart = self.get_user_cart(user_id)
        if not cart.items:
            print("Your cart is empty!")
            return

        try:
            product_id = int(input("Enter product ID to update: "))
            quantity = int(input("Enter new quantity: "))

            if self.update_cart_item(user_id, product_id, quantity):
                print("Quantity updated successfully!")
            else:
                print("Product not found in cart!")
        except ValueError:
            print("Invalid input!")

    def _remove_item(self, user_id):
        cart = self.get_user_cart(user_id)
        if not cart.items:
            print("Your cart is empty!")
            return

        try:
            product_id = int(input("Enter product ID to remove: "))
            self.remove_from_cart(user_id, product_id)
            print("Item removed from cart!")
        except ValueError:
            print("Invalid input!")
