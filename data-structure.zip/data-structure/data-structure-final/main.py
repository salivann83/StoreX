import csv
import os

from controllers.home import HomeController
from helpers.logger import Logger


def init_db():
    if not os.path.exists("./database"):
        os.makedirs("./database")

    if not os.path.exists("./database/product.csv"):
        with open("./database/product.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["id", "title", "category_id", "price", "score", "sell_count"]
            )

    if not os.path.exists("./database/category.csv"):
        with open("./database/category.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "title", "product_count"])

    if not os.path.exists("./database/carts.csv"):
        with open("./database/carts.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    "user_id",
                    "product_id",
                    "product_title",
                    "price",
                    "quantity",
                    "added_at",
                ]
            )

    if not os.path.exists("./database/logs.txt"):
        open("./database/logs.txt", "w").close()


if __name__ == "__main__":
    init_db()

    logger = Logger()

    home = HomeController(logger)

    current_user = 1
try:
    while True:
        try:
            home.home_page(current_user)
        except KeyboardInterrupt:
            print("\n\nThanks For Using melz Shop!")
            break

        try:
            input("\nPress Enter to continue...")
        except KeyboardInterrupt:
            print("\n\nThanks For Using melz Shop!")
            break
finally:
    logger.show_logs()
    print("\nLogs have been saved to database/logs.txt")
