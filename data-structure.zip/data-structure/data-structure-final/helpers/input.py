def input_handler(input_text="", min_command=1, max_command=10) -> int:
    command = ""
    while not isinstance(command, int):
        try:
            command = int(input(input_text))
            if command > max_command or command < min_command:
                print("Invalid Command: Out Of Range, Please Try Again")
                continue
        except Exception as _e:
            print("Invalid Command: Invalid Type, Please Try Again")
            continue
    return command
