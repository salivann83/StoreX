def validate_model(model_class, data: dict) -> bool:
    """Validate data against model requirements"""
    try:
        if model_class.__name__ == "Product":
            required_fields = ["title", "price", "category_id"]
            for field in required_fields:
                if field not in data or not data[field]:
                    return False

            float(data["price"])
            int(data["category_id"])

        elif model_class.__name__ == "Category":
            if "title" not in data or not data["title"].strip():
                return False

        return True
    except:
        return False
