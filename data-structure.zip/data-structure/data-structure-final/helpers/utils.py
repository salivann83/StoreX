import csv
from typing import List


def read_csv_with_headers(filepath: str) -> List[dict]:
    """Read CSV file with headers and return list of dictionaries"""
    data = []
    try:
        with open(filepath, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                data.append(row)
    except FileNotFoundError:
        pass
    return data


def write_csv_with_headers(filepath: str, data: List[dict], fieldnames: List[str]):
    """Write list of dictionaries to CSV with headers"""
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)


def convert_to_dict(obj):
    """Convert object to dictionary"""
    return vars(obj) if hasattr(obj, "__dict__") else obj
