import datetime


class Logger:
    def __init__(self):
        self.log_file = "database/logs.txt"
        self.logs = []

    def log_action(self, user_id, action, details=""):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] User:{user_id} - {action} - {details}"
        self.logs.append(log_entry)

        with open(self.log_file, "a") as f:
            f.write(log_entry + "\n")

    def show_logs(self):
        print("\n" + "=" * 60)
        print("USER ACTION LOGS:")
        print("=" * 60)
        for log in self.logs:
            print(log)
        print("=" * 60)
