from typing import List

from models.cart import CartItem


def cart_view(items: List[CartItem], total_price: float, total_items: int):
    """
    Display the shopping cart contents.

    Args:
        items: List of CartItem objects
        total_price: Total price of all items in cart
        total_items: Total quantity of all items in cart
    """
    print("\n" + "=" * 60)
    print("🛒 YOUR SHOPPING CART")
    print("=" * 60)

    if not items:
        print("\n✨ Your cart is empty! Add some products to get started.")
    else:
        print(f"{'ID':<8} {'PRODUCT':<30} {'PRICE':<12} {'QTY':<8} {'TOTAL':<12}")
        print("-" * 60)

        for item in items:
            print(
                f"{item.product_id:<8} "
                f"{item.product_title[:28]:<30} "
                f"${item.price:<11.2f} "
                f"{item.quantity:<8} "
                f"${item.total_price:<11.2f}"
            )

        print("-" * 60)
        print(f"📦 Total Items: {total_items}")
        print(f"💰 Total Price: ${total_price:.2f}")

        # Show cart summary
        print("\n" + "-" * 60)
        print("💡 Cart Summary:")
        print(f"  • Items: {len(items)} different products")
        print(f"  • Units: {total_items} total units")
        print(f"  • Value: ${total_price:.2f}")

        # Suggestions based on cart value
        if total_price > 100:
            print("  🎉 You qualify for free shipping!")
        if total_items > 5:
            print("  🏷️  Bulk purchase detected!")

    print("=" * 60)


def add_to_cart_form(product_title: str, product_price: float):
    """
    Form for adding a product to cart.

    Args:
        product_title: Title of the product
        product_price: Price of the product

    Returns:
        int: Quantity to add (or None if cancelled/invalid)
    """
    print("\n" + "🛍️" * 30)
    print("ADD TO CART")
    print("🛍️" * 30)
    print(f"\n📋 Product: {product_title}")
    print(f"💰 Price: ${product_price:.2f}")
    print("-" * 60)

    try:
        quantity = int(input("\nEnter quantity (1-99): "))

        if quantity <= 0:
            print("❌ Quantity must be positive!")
            return None
        elif quantity > 99:
            print("⚠️  Maximum quantity is 99. Setting to 99.")
            return 99
        else:
            print(f"\n✅ Adding {quantity} x {product_title} to cart...")
            print(f"   Subtotal: ${product_price * quantity:.2f}")
            return quantity
    except ValueError:
        print("❌ Invalid input! Please enter a number.")
        return None


def cart_menu_view():
    """
    Display the cart menu options.

    Returns:
        str: User's menu choice
    """
    print("\n" + "=" * 60)
    print("🛒 CART MENU")
    print("=" * 60)
    print("1. 👁️  View Cart Contents")
    print("2. ✏️  Update Item Quantity")
    print("3. ❌ Remove Item")
    print("4. 🧹 Clear Entire Cart")
    print("5. 💳 Checkout & Purchase")
    print("6. 🔙 Back to Main Menu")
    print("=" * 60)

    return input("Enter your choice (1-6): ").strip()


def update_cart_item_form(items: List[CartItem]):
    """
    Form for updating cart item quantity.

    Args:
        items: List of items in cart

    Returns:
        tuple: (product_id, new_quantity) or (None, None) if cancelled
    """
    print("\n" + "=" * 60)
    print("✏️ UPDATE CART ITEM")
    print("=" * 60)

    if not items:
        print("Your cart is empty!")
        return None, None

    # Display current items for reference
    print("Current items in cart:")
    print("-" * 60)
    for i, item in enumerate(items, 1):
        print(
            f"{i}. ID: {item.product_id}, {item.product_title}, "
            f"Qty: {item.quantity}, Price: ${item.price:.2f}"
        )
    print("-" * 60)

    try:
        choice = input("\nEnter item number to update (or '0' to cancel): ").strip()
        if choice == "0":
            print("Update cancelled.")
            return None, None

        index = int(choice) - 1
        if 0 <= index < len(items):
            item = items[index]
            print(f"\nSelected: {item.product_title}")
            print(f"Current quantity: {item.quantity}")
            print(f"Current total: ${item.total_price:.2f}")

            new_qty = int(input("\nEnter new quantity (0 to remove): "))

            if new_qty < 0:
                print("❌ Quantity cannot be negative!")
                return None, None

            if new_qty == 0:
                confirm = input(
                    f"Remove {item.product_title} from cart? (y/n): "
                ).lower()
                if confirm == "y":
                    return item.product_id, 0
                else:
                    print("Update cancelled.")
                    return None, None

            print(
                f"\n✅ Updating {item.product_title} from {item.quantity} to {new_qty}"
            )
            print(f"   New total: ${item.price * new_qty:.2f}")
            return item.product_id, new_qty
        else:
            print("❌ Invalid item number!")
            return None, None

    except ValueError:
        print("❌ Invalid input!")
        return None, None


def remove_cart_item_form(items: List[CartItem]):
    """
    Form for removing an item from cart.

    Args:
        items: List of items in cart

    Returns:
        int: Product ID to remove, or None if cancelled
    """
    print("\n" + "=" * 60)
    print("❌ REMOVE ITEM FROM CART")
    print("=" * 60)

    if not items:
        print("Your cart is empty!")
        return None

    # Display current items
    print("Select item to remove:")
    print("-" * 60)
    for i, item in enumerate(items, 1):
        print(
            f"{i}. ID: {item.product_id}, {item.product_title}, "
            f"Qty: {item.quantity}, Total: ${item.total_price:.2f}"
        )
    print("-" * 60)

    try:
        choice = input("\nEnter item number to remove (or '0' to cancel): ").strip()
        if choice == "0":
            print("Removal cancelled.")
            return None

        index = int(choice) - 1
        if 0 <= index < len(items):
            item = items[index]

            confirm = input(
                f"\nAre you sure you want to remove {item.product_title} "
                f"(Qty: {item.quantity}, Total: ${item.total_price:.2f})? (y/n): "
            ).lower()

            if confirm == "y":
                print(f"✅ Removing {item.product_title} from cart...")
                return item.product_id
            else:
                print("Removal cancelled.")
                return None
        else:
            print("❌ Invalid item number!")
            return None

    except ValueError:
        print("❌ Invalid input!")
        return None


def clear_cart_confirmation(items: List[CartItem]):
    """
    Confirmation dialog for clearing cart.

    Args:
        items: List of items in cart

    Returns:
        bool: True if confirmed, False if cancelled
    """
    if not items:
        print("Cart is already empty!")
        return False

    print("\n" + "=" * 60)
    print("⚠️  CLEAR ENTIRE CART")
    print("=" * 60)

    total_items = sum(item.quantity for item in items)
    total_price = sum(item.total_price for item in items)

    print(f"You are about to clear your entire cart containing:")
    print(f"  • {len(items)} different products")
    print(f"  • {total_items} total units")
    print(f"  • ${total_price:.2f} total value")
    print("\nThis action cannot be undone!")

    confirm = input("\nAre you absolutely sure? (Type 'YES' to confirm): ").strip()

    if confirm == "YES":
        print("✅ Cart cleared successfully!")
        return True
    else:
        print("❌ Cart clearance cancelled.")
        return False


def checkout_view(items: List[CartItem], total_price: float, total_items: int):
    """
    Display checkout summary.

    Args:
        items: List of CartItem objects
        total_price: Total price
        total_items: Total quantity

    Returns:
        bool: True if user confirms purchase, False otherwise
    """
    print("\n" + "=" * 60)
    print("💳 CHECKOUT")
    print("=" * 60)

    if not items:
        print("Your cart is empty! Add items before checkout.")
        return False

    # Order summary
    print("📋 ORDER SUMMARY")
    print("-" * 60)

    for item in items:
        print(f"  {item.quantity} x {item.product_title}")
        print(f"    ${item.price:.2f} each = ${item.total_price:.2f}")

    print("-" * 60)
    print(f"📦 Total Items: {total_items}")
    print(f"💰 Subtotal: ${total_price:.2f}")

    # Calculate taxes and fees (simplified)
    tax_rate = 0.08  # 8% tax
    tax_amount = total_price * tax_rate
    shipping_fee = 0.0 if total_price > 50 else 5.99
    grand_total = total_price + tax_amount + shipping_fee

    print(f"🧾 Tax ({tax_rate * 100:.0f}%): ${tax_amount:.2f}")

    if shipping_fee > 0:
        print(f"🚚 Shipping: ${shipping_fee:.2f}")
        print("   💡 Spend $50+ for free shipping!")
    else:
        print(f"🚚 Shipping: FREE")

    print("-" * 60)
    print(f"💰 GRAND TOTAL: ${grand_total:.2f}")
    print("=" * 60)

    # Payment options
    print("\n💳 PAYMENT OPTIONS")
    print("1. 💵 Cash on Delivery")
    print("2. 💳 Credit/Debit Card")
    print("3. 📱 Digital Wallet")
    print("4. 🏦 Bank Transfer")

    try:
        payment_method = int(input("\nSelect payment method (1-4): "))
        if payment_method not in [1, 2, 3, 4]:
            print("❌ Invalid payment method!")
            return False
    except ValueError:
        print("❌ Invalid input!")
        return False

    # Confirmation
    print("\n" + "=" * 60)
    print("📝 ORDER CONFIRMATION")
    print("=" * 60)

    print("\nPlease review your order:")
    print(f"  • Items: {total_items}")
    print(f"  • Total: ${grand_total:.2f}")
    print(f"  • Payment: Option {payment_method}")

    confirm = input("\nConfirm purchase? (y/n): ").lower()

    if confirm == "y":
        print("\n✅ ORDER CONFIRMED!")
        print("Thank you for your purchase!")
        print("\n📦 Your items will be shipped soon.")
        print("📧 You will receive an email confirmation.")
        return True
    else:
        print("\n❌ Purchase cancelled.")
        return False


def order_history_view(orders: List[dict]):
    """
    Display order history.

    Args:
        orders: List of order dictionaries
    """
    print("\n" + "=" * 60)
    print("📦 ORDER HISTORY")
    print("=" * 60)

    if not orders:
        print("\nNo previous orders found.")
        print("Start shopping to see your order history here!")
    else:
        print(f"\nFound {len(orders)} previous orders:")
        print("-" * 60)

        for i, order in enumerate(orders, 1):
            print(f"\nOrder #{i}:")
            print(f"  Date: {order.get('date', 'Unknown')}")
            print(f"  Items: {order.get('total_items', 0)}")
            print(f"  Total: ${order.get('total_price', 0):.2f}")
            print(f"  Status: {order.get('status', 'Completed')}")

        print("-" * 60)
        print(f"Total Orders: {len(orders)}")
        print(
            f"Lifetime Spend: ${sum(order.get('total_price', 0) for order in orders):.2f}"
        )


def cart_empty_view():
    """Display when cart is empty."""
    print("\n" + "=" * 60)
    print("🛒 YOUR CART IS EMPTY")
    print("=" * 60)
    print("\n✨ Discover amazing products to add to your cart!")
    print("\n💡 Suggestions:")
    print("  1. Browse products from the main menu")
    print("  2. Check out featured products")
    print("  3. View your recently watched items")
    print("  4. Search for products you love")
    print("=" * 60)


def cart_item_added_view(
    item: CartItem, cart_total_items: int, cart_total_price: float
):
    """
    Display confirmation when item is added to cart.

    Args:
        item: The CartItem that was added
        cart_total_items: New total items in cart
        cart_total_price: New total price of cart
    """
    print("\n" + "✅" * 30)
    print("ITEM ADDED TO CART!")
    print("✅" * 30)
    print(f"\n📋 Product: {item.product_title}")
    print(f"💰 Price: ${item.price:.2f}")
    print(f"📦 Quantity: {item.quantity}")
    print(f"🧮 Subtotal: ${item.total_price:.2f}")
    print("-" * 60)
    print(f"🛒 Cart now has: {cart_total_items} items")
    print(f"💰 Cart total: ${cart_total_price:.2f}")
    print("-" * 60)

    # Suggestions
    if cart_total_price < 50:
        needed = 50 - cart_total_price
        print(f"\n💡 Add ${needed:.2f} more for FREE shipping!")

    print("\nOptions:")
    print("1. Continue shopping")
    print("2. View cart")
    print("3. Checkout now")
    print("=" * 60)


def cart_updated_view():
    """Display when cart is updated successfully."""
    print("\n✅ Cart updated successfully!")
    print("Your changes have been saved.")


def cart_error_view(error_message: str):
    """
    Display cart error messages.

    Args:
        error_message: Error message to display
    """
    print("\n" + "❌" * 30)
    print("CART ERROR")
    print("❌" * 30)
    print(f"\n{error_message}")
    print("\nPlease try again or contact support.")
    print("=" * 60)
