from typing import List

from helpers.input import input_handler
from models.category import Category


def create_page_form():
    print("\n" + "=" * 60)
    print("""
      CREATE NEW CATEGORY
    """)
    print("=" * 60)
    title = input("Enter New Category Title*: ").strip()
    return {"title": title}


def list_page_form():
    print("\n" + "=" * 60)
    print("""
      CATEGORY LIST
    """)
    print("=" * 60)

    sortBy = input_handler(
        """
    How do you want to sort categories?
    1. ID (Ascending)
    2. ID (Descending)
    3. Title (Ascending)
    4. Title (Descending)
    5. Product Count (Ascending)
    6. Product Count (Descending)

    Enter your choice (1-6): """,
        1,
        6,
    )

    return sortBy


def list_page_view(items: List[Category]):
    print("\n" + "=" * 60)
    print("CATEGORIES:")
    print("=" * 60)

    if len(items) > 0:
        print(f"{'ID':<5} {'Title':<30} {'Products':<10}")
        print("-" * 60)
        for category in items:
            print(f"{category.id:<5} {category.title:<30} {category.product_count:<10}")
        print("-" * 60)
        print(f"Total Categories: {len(items)}")
    else:
        print("No categories found.")
    print("=" * 60)


def search_form():
    print("\n" + "=" * 60)
    print("""
      SEARCH CATEGORIES
    """)
    print("=" * 60)
    query = input("Enter search query: ").strip()
    return query


def search_view(items: List[Category]):
    print("\n" + "=" * 60)
    print("SEARCH RESULTS:")
    print("=" * 60)

    if len(items) > 0:
        print(f"{'ID':<5} {'Title':<30} {'Products':<10}")
        print("-" * 60)
        for category in items:
            print(f"{category.id:<5} {category.title:<30} {category.product_count:<10}")
        print("-" * 60)
        print(f"Found {len(items)} categories")
    else:
        print("No matching categories found.")
    print("=" * 60)


def update_page_form():
    print("\n" + "=" * 60)
    print("""
      UPDATE CATEGORY
    """)
    print("=" * 60)

    category_id = int(input("Enter Category ID to update: "))

    print("\nLeave field blank to keep current value:")
    title = input("New Title: ").strip()

    data = {}
    if title:
        data["title"] = title

    return category_id, data


def delete_page_form():
    print("\n" + "=" * 60)
    print("""
      DELETE CATEGORY
    """)
    print("=" * 60)

    category_id = int(input("Enter Category ID to delete: "))

    # Confirm deletion
    confirm = input(
        f"Are you sure you want to delete category {category_id}? (y/n): "
    ).lower()
    if confirm != "y":
        print("Deletion cancelled.")
        return None

    return category_id
