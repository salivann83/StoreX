def home_page_view():
    print("""
  Welcome to melz offline shop:
   1. Get Products List
   2. Create A New Product
   3. Search In Products
   4. Get Category List
   5. Create A New Category
   6. Search In Category
   7. Update Product
   8. Delete Product
   9. Find Similar Products
   10. Exit
""")
