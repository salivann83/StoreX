from typing import List

from helpers.input import input_handler
from models.product import Product


def create_page_form():
    print("\n" + "(-_-)" * 30)
    print("""
      You Are Adding A New Product
      """)
    title = input("Enter New Product's Title*: ")
    price = float(input("Enter New Product's Price:"))
    category_id = int(input("Enter New Product's Category ID:"))
    return dict({"title": title, "price": price, "category_id": category_id})


def list_page_form():
    print("\n" + "(-_-)" * 30)
    # handle categories
    print("""
      Products List
    """)
    category_id = 1
    sortBy = input_handler("""
    How Do You Want The Products To Be Sorted On?
      1. ID (Ascending)
      2. ID (Descending)
      3. Title (Ascending)
      4. Title (Descending)
      5. Price (Ascending)
      6. Price (Descending)
    """, 1, 6)
    return sortBy, category_id


def list_page_view(items: List[Product]):
    if len(items) > 0:
        print("id, title, category_id, price")
        for product in items:
            print(
                f"{product.id}, {product.title}, {product.category_id}, {product.price}"
            )
    else:
        print("No Result")


def search_form():
    print("\n" + "(-_-)" * 30)
    print("""
    Search In Products
  """)
    return input("What Are You Looking for? ")


def search_view(items: List[Product]):
    print("""
    Product Search Result:
      """)
    list_page_view(items)


def update_page_form():
    print("\n" + "(-_-)" * 30)
    print("""
      Update Product
    """)
    product_id = int(input("Enter Product ID to update: "))

    print("Leave field blank to keep current value:")
    title = input("New Title: ")
    price_input = input("New Price: ")
    category_input = input("New Category ID: ")

    data = {}
    if title:
        data["title"] = title
    if price_input:
        data["price"] = float(price_input)
    if category_input:
        data["category_id"] = int(category_input)

    return product_id, data


def delete_page_form():
    print("\n" + "(-_-)" * 30)
    print("""
      Delete Product
    """)
    return int(input("Enter Product ID to delete: "))


def similar_products_form():
    print("\n" + "(-_-)" * 30)
    print("""
      Find Similar Products
    """)
    product_id = int(input("Enter Product ID: "))

    print("\nFind similar products by:")
    print("1. Same Category")
    print("2. Similar Price (±20%)")
    print("3. Most Bought in Same Category")

    criteria = input_handler("Enter criteria (1-3): ", 1, 3)
    limit = int(input("Maximum number of similar products to show: "))

    return product_id, criteria, limit


def similar_products_view(main_product: Product, similar_products: List[Product]):
    print("\n" + "=" * 60)
    print(f"MAIN PRODUCT:")
    print(f"ID: {main_product.id}, Title: {main_product.title}")
    print(f"Category: {main_product.category_id}, Price: ${main_product.price:.2f}")
    print("=" * 60)

    if similar_products:
        print(f"\nSIMILAR PRODUCTS ({len(similar_products)} found):")
        print("-" * 60)
        for product in similar_products:
            print(f"ID: {product.id}, Title: {product.title}")
            print(f"Category: {product.category_id}, Price: ${product.price:.2f}")
            print(f"Sold: {product.sell_count} times")
            print("-" * 30)
    else:
        print("\nNo similar products found.")

    print("=" * 60)


def recently_watched_view(recent_products: list, limit: int):
    print("\n" + "=" * 60)
    print(f"RECENTLY WATCHED PRODUCTS (Last {limit})")
    print("=" * 60)

    if not recent_products:
        print("No recently watched products.")
    else:
        print(f"{'ID':<10} {'Product':<30} {'Price':<10} {'Category':<15}")
        print("-" * 60)
        for product in recent_products[-limit:]:  # Show last N items
            print(
                f"{product.id:<10} {product.title:<30} ${product.price:<9.2f} {product.category_id:<15}"
            )
    print("=" * 60)

    print("\nOptions:")
    print("1. View Product Details")
    print("2. Change Number of Recent Products to Show")
    print("3. Back to Main Menu")
    print("=" * 60)

    return input("Enter your choice (1-3): ")


def set_recent_limit_form(current_limit: int):
    print("\n" + "=" * 60)
    print(f"Current limit: {current_limit} products")
    print("=" * 60)

    try:
        new_limit = int(input("Enter new limit (1-20): "))
        if 1 <= new_limit <= 20:
            return new_limit
        else:
            print("Limit must be between 1 and 20!")
            return current_limit
    except ValueError:
        print("Invalid input!")
        return current_limit


def add_to_cart_form(product_title: str, product_price: float, current_stock: int = 0):
    """
    Form for adding a product to the shopping cart.

    Args:
        product_title: Name of the product
        product_price: Price of the product
        current_stock: Current available stock (optional)

    Returns:
        int: Quantity to add to cart, or None if cancelled
    """
    print("\n" + "🛍️" * 30)
    print("ADD TO SHOPPING CART")
    print("🛍️" * 30)
    print(f"\n📋 Product: {product_title}")
    print(f"💰 Price: ${product_price:.2f}")

    if current_stock is not None:
        print(f"📦 Available Stock: {current_stock}")

    print("-" * 60)

    # Show price breakdown for different quantities
    print("\n💡 Price breakdown:")
    for qty in [1, 2, 3, 5, 10]:
        total = product_price * qty
        print(f"  {qty} x = ${total:.2f}")

    print("-" * 60)

    try:
        quantity = int(input("\nEnter quantity to add to cart (1-99): "))

        if quantity <= 0:
            print("❌ Quantity must be greater than 0!")
            return None

        if quantity > 99:
            print("⚠️  Maximum quantity per order is 99.")
            confirm = input("Add 99 to cart instead? (y/n): ").lower()
            if confirm == "y":
                quantity = 99
            else:
                return None

        if current_stock is not None and quantity > current_stock:
            print(f"❌ Only {current_stock} units available!")
            confirm = input(f"Add {current_stock} to cart instead? (y/n): ").lower()
            if confirm == "y":
                quantity = current_stock
            else:
                return None

        # Show confirmation
        subtotal = product_price * quantity
        print(f"\n✅ Adding to cart:")
        print(f"   Product: {product_title}")
        print(f"   Quantity: {quantity}")
        print(f"   Unit Price: ${product_price:.2f}")
        print(f"   Subtotal: ${subtotal:.2f}")

        confirm = input("\nConfirm add to cart? (y/n): ").lower()
        if confirm == "y":
            return quantity
        else:
            print("❌ Cancelled adding to cart.")
            return None

    except ValueError:
        print("❌ Please enter a valid number!")
        return None


def product_detail_view(product, category_title=None, similar_products=None):
    """
    Detailed view of a single product with options.

    Args:
        product: Product object
        category_title: Title of the category (optional)
        similar_products: List of similar products (optional)
    """
    print("\n" + "=" * 70)
    print("📋 PRODUCT DETAILS")
    print("=" * 70)

    print(f"\n🆔 ID: {product.id}")
    print(f"📛 Title: {product.title}")

    if category_title:
        print(f"🏷️  Category: {category_title} (ID: {product.category_id})")
    else:
        print(f"🏷️  Category ID: {product.category_id}")

    print(f"💰 Price: ${product.price:.2f}")
    print(f"⭐ Rating Score: {product.score}/5")
    print(f"📦 Units Sold: {product.sell_count}")

    revenue = product.price * product.sell_count
    print(f"💵 Total Revenue: ${revenue:.2f}")

    stock_status = "In Stock" if product.sell_count < 1000 else "Limited Stock"
    print(f"📊 Stock Status: {stock_status}")

    print("\n" + "-" * 70)

    if similar_products:
        print("\n🔄 SIMILAR PRODUCTS YOU MIGHT LIKE:")
        print("-" * 70)
        print(f"{'ID':<6} {'Product':<25} {'Price':<12} {'Sold':<10} {'Category':<10}")
        print("-" * 70)

        for i, similar in enumerate(similar_products[:5], 1):
            print(
                f"{similar.id:<6} "
                f"{similar.title[:24]:<25} "
                f"${similar.price:<11.2f} "
                f"{similar.sell_count:<10} "
                f"{similar.category_id:<10}"
            )

        print("-" * 70)
        print(
            f"Showing {len(similar_products[:5])} of {len(similar_products)} similar products"
        )

    print("\n" + "=" * 70)
    print("🔧 AVAILABLE ACTIONS")
    print("=" * 70)
    print("1. 🛍️  Add to Cart")
    print("2. 🔄 View More Similar Products")
    print("3. ✏️  Edit This Product")
    print("4. 📊 View Sales Statistics")
    print("5. 📋 View in Different Category")
    print("6. ⭐ Rate This Product")
    print("7. 💾 Save to Wishlist")
    print("8. 🔙 Back to Product List")
    print("9. 🏠 Back to Main Menu")
    print("=" * 70)

    try:
        choice = int(input("\nSelect an option (1-9): "))
        return choice
    except ValueError:
        print("❌ Invalid input! Please enter a number.")
        return None


def product_detail_simple_view(product):
    """
    Simple product detail view without complex options.
    Useful for quick previews.
    """
    print("\n" + "-" * 50)
    print(f"📋 {product.title}")
    print("-" * 50)
    print(f"🆔 ID: {product.id}")
    print(f"💰 Price: ${product.price:.2f}")
    print(f"🏷️  Category: {product.category_id}")
    print(f"⭐ Rating: {product.score}/5")
    print(f"📦 Sold: {product.sell_count}")

    print("\n" + "-" * 50)
    add_cart = input("Add to cart? (y/n): ").lower()

    if add_cart == "y":
        try:
            qty = int(input("Quantity (default 1): ") or "1")
            if qty > 0:
                return qty
            else:
                print("❌ Quantity must be positive!")
                return None
        except ValueError:
            print("❌ Invalid quantity!")
            return None

    return None


def product_quick_view(products):
    """
    Quick view of multiple products with minimal details.

    Args:
        products: List of product objects
    """
    print("\n" + "=" * 70)
    print("🔍 QUICK PRODUCT VIEW")
    print("=" * 70)

    if not products:
        print("No products to display.")
        return None

    print(f"\nFound {len(products)} products:")
    print("-" * 70)
    print(f"{'#':<3} {'ID':<6} {'Product':<25} {'Price':<12} {'Category':<10}")
    print("-" * 70)

    for i, product in enumerate(products, 1):
        print(
            f"{i:<3} "
            f"{product.id:<6} "
            f"{product.title[:24]:<25} "
            f"${product.price:<11.2f} "
            f"{product.category_id:<10}"
        )

    print("-" * 70)

    try:
        selection = input("\nEnter product number to view details (or 0 to cancel): ")
        if selection == "0":
            return None

        index = int(selection) - 1
        if 0 <= index < len(products):
            return products[index].id
        else:
            print("❌ Invalid selection!")
            return None
    except ValueError:
        print("❌ Please enter a valid number!")
        return None


def product_comparison_view(products):
    """
    Compare multiple products side by side.

    Args:
        products: List of product objects (2-4 recommended)
    """
    if len(products) < 2:
        print("Need at least 2 products to compare!")
        return

    print("\n" + "=" * 100)
    print("⚖️  PRODUCT COMPARISON")
    print("=" * 100)

    headers = ["Feature", "Product 1", "Product 2", "Product 3", "Product 4"][
        : len(products) + 1
    ]
    print(f"{headers[0]:<20} ", end="")
    for i in range(1, len(headers)):
        print(f"{headers[i]:<25} ", end="")
    print()

    print("-" * 100)

    print(f"{'Title':<20} ", end="")
    for product in products:
        print(f"{product.title[:23]:<25} ", end="")
    print()

    print(f"{'Price':<20} ", end="")
    for product in products:
        print(f"${product.price:<24.2f} ", end="")
    print()

    print(f"{'Category ID':<20} ", end="")
    for product in products:
        print(f"{product.category_id:<25} ", end="")
    print()

    print(f"{'Rating':<20} ", end="")
    for product in products:
        stars = "★" * product.score + "☆" * (5 - product.score)
        print(f"{stars:<25} ", end="")
    print()

    print(f"{'Units Sold':<20} ", end="")
    for product in products:
        print(f"{product.sell_count:<25} ", end="")
    print()

    print(f"{'Value Score':<20} ", end="")
    for product in products:
        if product.sell_count > 0:
            value_score = product.price / product.sell_count
            print(f"{value_score:.4f}{' ':<21} ", end="")
        else:
            print(f"N/A{' ':<22} ", end="")
    print()

    print("-" * 100)

    print("\n💡 RECOMMENDATIONS:")

    cheapest = min(products, key=lambda x: x.price)
    print(f"  • 🏷️  Best Price: {cheapest.title} (${cheapest.price:.2f})")

    best_seller = max(products, key=lambda x: x.sell_count)
    if best_seller.sell_count > 0:
        print(
            f"  • 📈 Most Popular: {best_seller.title} ({best_seller.sell_count} sold)"
        )

    highest_rated = max(products, key=lambda x: x.score)
    if highest_rated.score > 0:
        print(f"  • ⭐ Top Rated: {highest_rated.title} ({highest_rated.score}/5)")

    print("=" * 100)

    print("\nSelect a product to add to cart:")
    for i, product in enumerate(products, 1):
        print(f"{i}. {product.title} - ${product.price:.2f}")
    print(f"{len(products) + 1}. Compare different products")
    print(f"{len(products) + 2}. Back to menu")

    try:
        choice = int(input(f"\nEnter choice (1-{len(products) + 2}): "))
        return choice
    except ValueError:
        return None


def clear_recent_history_confirmation(count: int):
    """
    Confirmation dialog for clearing recently watched history.

    Args:
        count: Number of items in history

    Returns:
        bool: True if confirmed, False if cancelled
    """
    print("\n" + "=" * 60)
    print("⚠️  CLEAR RECENTLY WATCHED HISTORY")
    print("=" * 60)

    if count == 0:
        print("\nYour watch history is already empty!")
        return False

    print(f"\nYou are about to clear {count} items from your watch history.")
    print("This action cannot be undone!")
    print("\nClearing your history will:")
    print("  • Remove all recently watched products")
    print("  • Reset your browsing history")
    print("  • Clear personalized recommendations")

    print("\n" + "-" * 60)
    confirm = input("\nType 'CLEAR HISTORY' to confirm: ").strip()

    if confirm == "CLEAR HISTORY":
        print("✅ Watch history cleared successfully!")
        return True
    else:
        print("❌ Clear history cancelled.")
        return False


def product_detail_full_view(product: Product, category_title: str = ""):
    print("\n" + "=" * 70)
    print("📋 PRODUCT DETAILS")
    print("=" * 70)

    print("\n📝 BASIC INFORMATION:")
    print("-" * 70)
    print(f"🆔 Product ID: {product.id}")
    print(f"📛 Title: {product.title}")

    if category_title:
        print(f"🏷️  Category: {category_title}")
    print(f"📊 Category ID: {product.category_id}")

    print("\n💰 PRICING INFORMATION:")
    print("-" * 70)
    print(f"Price: ${product.price:.2f}")

    print(f"   • EUR: €{product.price * 0.85:.2f}")
    print(f"   • GBP: £{product.price * 0.73:.2f}")
    print(f"   • JPY: ¥{product.price * 110:.0f}")

    print("\n📈 SALES PERFORMANCE:")
    print("-" * 70)
    print(f"Units Sold: {product.sell_count}")
    print(f"Total Revenue: ${product.price * product.sell_count:.2f}")

    print("\n⭐ CUSTOMER RATINGS:")
    print("-" * 70)
    stars = "★" * product.score + "☆" * (5 - product.score)
    print(f"Rating: {stars} ({product.score}/5)")

    print("\n📦 AVAILABILITY:")
    print("-" * 70)

    if product.sell_count < 50:
        stock_level = "High Stock"
        stock_count = 1000 - product.sell_count
    elif product.sell_count < 200:
        stock_level = "Medium Stock"
        stock_count = 500 - product.sell_count
    else:
        stock_level = "Low Stock"
        stock_count = 100 - (product.sell_count % 100)

    print(f"Stock Level: {stock_level}")
    print(f"Estimated Available: {max(0, stock_count)} units")

    print("\n💎 VALUE INDICATORS:")
    print("-" * 70)

    if product.sell_count > 0:
        price_per_unit = product.price / product.sell_count
        print(f"Price per Unit Sold: ${price_per_unit:.4f}")

    popularity = min(100, product.sell_count * 2)
    print(f"Popularity Score: {popularity}/100")

    if product.price < 10:
        price_category = "Budget"
    elif product.price < 50:
        price_category = "Standard"
    elif product.price < 100:
        price_category = "Premium"
    else:
        price_category = "Luxury"

    print(f"Price Category: {price_category}")

    print("\n" + "=" * 70)
    print("🛍️  SHOPPING OPTIONS")
    print("=" * 70)

    return {
        "product": product,
        "category_title": category_title,
        "stock_count": max(0, stock_count),
    }
